import siderTrigger from './sider-trigger.vue'
export default siderTrigger
